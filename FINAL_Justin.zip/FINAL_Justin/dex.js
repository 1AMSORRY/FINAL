// 로그인 버튼 클릭 시 (예시)
document.getElementById("login-btn").addEventListener("click", () => {
    const username = "사용자123"; // 실제 구현에서는 사용자가 입력한 ID를 가져와야 합니다.
    localStorage.setItem('username', username);
    updateAuthDisplay(); // UI 업데이트
});

// 로그아웃 버튼 클릭 시
document.getElementById("logout-button").addEventListener("click", () => {
    localStorage.removeItem('username');
    updateAuthDisplay(); // UI 업데이트
});

// 인증 상태에 따라 UI 업데이트
function updateAuthDisplay() {
    const authLinks = document.getElementById("auth-links");
    const usernameContainer = document.getElementById("username-container");

    if (isLoggedIn()) {
        const username = localStorage.getItem('username');
        authLinks.style.display = "none";
        usernameContainer.style.display = "inline-block";
        document.getElementById("username").textContent = username; // 사용자 이름 표시
    } else {
        authLinks.style.display = "inline-block";
        usernameContainer.style.display = "none";
    }
}
// 페이지 로드 시 초기 업데이트
updateAuthDisplay();

// 사용자 인증 상태 확인 함수 (예시: 로컬 스토리지에 username이 있는지 확인)
function isLoggedIn() {
    return localStorage.getItem('username') !== null;
}